import { db } from "./firebase.js";
import {
  ref,
  push,
  remove
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

window.addMatBang = function () {
  const data = {
    ten: ten.value,
    diachi: diachi.value,
    gia: Number(gia.value),
    dientich: Number(dientich.value),
    hinhanh: hinhanh.value,
    loai: "Shop",
    danhgia: 5,
    phan_khuc: "caocap"
  };

  push(ref(db, "matbang"), data)
    .then(() => alert("Đã thêm mặt bằng"))
    .catch(err => alert(err.message));
};

window.deleteMatBang = function (id) {
  remove(ref(db, "matbang/" + id));
};
let currentEditId = null;

// 🟢 MỞ MODAL SỬA
window.openEdit = async (id) => {
  currentEditId = id;

  const snap = await get(ref(db, `matbang/${id}`));
  const d = snap.val();

  edit_ten.value = d.ten;
  edit_diachi.value = d.diachi;
  edit_gia.value = d.gia;
  edit_dientich.value = d.dientich;
  edit_loai.value = d.loai;
  edit_phan_khuc.value = d.phan_khuc;
  edit_hinhanh.value = d.hinhanh;

  document.getElementById("editModal").style.display = "flex";
};

// ❌ ĐÓNG MODAL
window.closeModal = () => {
  document.getElementById("editModal").style.display = "none";
};

// 💾 LƯU CHỈNH SỬA
window.saveEdit = async () => {
  await update(ref(db, `matbang/${currentEditId}`), {
    ten: edit_ten.value,
    diachi: edit_diachi.value,
    gia: Number(edit_gia.value),
    dientich: Number(edit_dientich.value),
    loai: edit_loai.value,
    phan_khuc: edit_phan_khuc.value,
    hinhanh: edit_hinhanh.value
  });

  alert("Đã cập nhật");
  closeModal();
};

// 🗑 XOÁ
window.deletePost = async (id) => {
  if (!confirm("Xóa bài này?")) return;
  await remove(ref(db, `matbang/${id}`));
};