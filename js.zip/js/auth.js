import { auth, db } from "./firebase.js";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { ref, get } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

/* =========================
   🔥 BIẾN TOÀN CỤC QUYỀN
========================= */
window.currentUserRole = "guest";

/* =========================
   🔐 LOGIN / REGISTER
========================= */
window.login = async () => {
  await signInWithEmailAndPassword(auth, emailInput.value, passwordInput.value);
  location.href = "index.html";
};

window.register = async () => {
  await createUserWithEmailAndPassword(auth, emailInput.value, passwordInput.value);
  location.href = "index.html";
};

/* =========================
   👤 AUTH STATE
========================= */
onAuthStateChanged(auth, async (user) => {
  const btnAddPost = document.getElementById("btnAddPost");
  const authButtons = document.getElementById("authButtons");
  const userBox = document.getElementById("userBox");

  if (!user) {
    window.currentUserRole = "guest";
    if (authButtons) authButtons.style.display = "block";
    if (btnAddPost) btnAddPost.style.display = "none";
    if (userBox) userBox.innerHTML = "";
    return;
  }

  if (authButtons) authButtons.style.display = "none";

  // 🔥 LẤY ROLE
  const snap = await get(ref(db, `user/${user.uid}`));
  if (snap.exists()) {
    window.currentUserRole = snap.val().role;
  } else {
    window.currentUserRole = "user";
  }

  if (btnAddPost && window.currentUserRole === "admin") {
    btnAddPost.style.display = "inline-block";
  }

  userBox.innerHTML = `
    ${user.email} (${window.currentUserRole})
    <button onclick="logout()">Đăng xuất</button>
  `;

  // 🔥 QUAN TRỌNG
  window.dispatchEvent(new Event("role-ready"));
});

/* =========================
   🚪 LOGOUT
========================= */
window.logout = () => signOut(auth);
