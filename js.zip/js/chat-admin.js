import { auth, db } from "./firebase.js";
import { ref, onValue, push, get }
  from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

/* ================= ELEMENT ================= */
const userList = document.getElementById("userList");
const messagesBox = document.getElementById("chatMessages");
const input = document.getElementById("replyText");
const sendBtn = document.getElementById("btnSend");
const chatWithText = document.getElementById("chatWithText");

/* ================= STATE (BẮT BUỘC GLOBAL) ================= */
let currentUID = null;
let currentUserEmail = "";
let currentMessagesRef = null;

/* ================= CHECK ADMIN ROLE ================= */
onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("Vui lòng đăng nhập admin");
    location.href = "login.html";
    return;
  }

  const roleSnap = await get(ref(db, `user/${user.uid}/role`));

  if (!roleSnap.exists() || roleSnap.val() !== "admin") {
    alert("Bạn không có quyền truy cập");
    location.href = "index.html";
    return;
  }

  initAdminChat();
});

/* ================= LOAD USER CHAT LIST ================= */
function initAdminChat() {
  onValue(ref(db, "adminChats"), snap => {
    console.log("ADMIN CHATS SNAP:", snap.val()); // DEBUG

    userList.innerHTML = "";

    if (!snap.exists()) {
      userList.innerHTML =
        "<p style='padding:12px'>Chưa có user chat</p>";
      return;
    }

    snap.forEach(child => {
      const uid = child.key;
      const data = child.val();
      const email = data.userEmail || uid;

      const div = document.createElement("div");
      div.className = "user-item";
      div.innerText = email;

      div.onclick = () => openChat(uid, email, div);

      userList.appendChild(div);
    });
  });
}

/* ================= OPEN CHAT ================= */
function openChat(uid, email, el) {
  currentUID = uid;
  currentUserEmail = email;

  // ===== UPDATE HEADER =====
  if (chatWithText) {
    chatWithText.innerText = `Đang chat với: ${email}`;
  }

  // ===== HIGHLIGHT ACTIVE USER =====
  document.querySelectorAll(".user-item")
    .forEach(item => item.classList.remove("active"));
  el.classList.add("active");

  // ===== REMOVE OLD LISTENER (FIX LỖI “VẪN VẬY”) =====
  if (currentMessagesRef) {
    currentMessagesRef.off();
  }

  // ===== LISTEN NEW USER =====
  currentMessagesRef = ref(db, `adminChats/${uid}/messages`);

  onValue(currentMessagesRef, snap => {
    messagesBox.innerHTML = "";

    snap.forEach(c => {
      const m = c.val();
      messagesBox.innerHTML += `
        <div class="msg ${m.from}">
          ${m.text}
        </div>
      `;
    });

    messagesBox.scrollTop = messagesBox.scrollHeight;
  });
}

/* ================= SEND MESSAGE ================= */
sendBtn.onclick = async () => {
  if (!currentUID) {
    alert("Vui lòng chọn user để chat");
    return;
  }

  const text = input.value.trim();
  if (!text) return;

  await push(ref(db, `adminChats/${currentUID}/messages`), {
    from: "admin",
    text,
    time: Date.now()
  });

  input.value = "";
};
