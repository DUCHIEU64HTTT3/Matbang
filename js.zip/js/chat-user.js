import { auth, db } from "./firebase.js";
import { ref, push, onValue, update }
  from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

let currentUser = null;
let messagesRef = null;

/* ===== AUTH ===== */
onAuthStateChanged(auth, user => {
  if (!user) {
    alert("Vui lòng đăng nhập để chat");
    location.href = "login.html";
    return;
  }

  currentUser = user;
  messagesRef = ref(db, `adminChats/${user.uid}/messages`);

  // Lưu thông tin user
  update(ref(db, `adminChats/${user.uid}`), {
    userEmail: user.email,
    updatedAt: Date.now()
  });

  listenMessages();
});

/* ===== LISTEN CHAT ===== */
function listenMessages() {
  onValue(messagesRef, snap => {
    const box = document.getElementById("chatMessages");
    box.innerHTML = "";

    snap.forEach(child => {
      const m = child.val();
      box.innerHTML += `
        <div class="msg ${m.from}">
          ${m.text}
        </div>
      `;
    });

    box.scrollTop = box.scrollHeight;
  });
}

/* ===== SEND MESSAGE ===== */
document.getElementById("btnSendChat").onclick = async () => {
  if (!currentUser || !messagesRef) return;

  const input = document.getElementById("chatText");
  const text = input.value.trim();
  if (!text) return;

  await push(messagesRef, {
    from: "user",
    text,
    time: Date.now()
  });

  await update(ref(db, `adminChats/${currentUser.uid}`), {
    lastMessage: text,
    updatedAt: Date.now()
  });

  input.value = "";
};
