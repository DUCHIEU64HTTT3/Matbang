document.addEventListener("DOMContentLoaded", () => {

  const WEBHOOK_URL =
    "https://hieu2006.app.n8n.cloud/webhook/matbang-query";

  const chatBox = document.getElementById("chatBox");
  const messagesEl = document.getElementById("chatMessages");
  const inputEl = document.getElementById("chatInput");
  const btnChat = document.getElementById("btnChat");

  /* ===== TOGGLE CHAT ===== */
  btnChat.addEventListener("click", () => {
    chatBox.classList.toggle("open");
    if (chatBox.classList.contains("open")) {
      setTimeout(() => inputEl.focus(), 100);
    }
  });

  /* ===== UI HELPERS ===== */
  function addUser(text) {
    messagesEl.innerHTML += `
      <div class="msg user">
        <div class="bubble">${text}</div>
      </div>
    `;
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function addBot(text) {
    messagesEl.innerHTML += `
      <div class="msg bot">
        <div class="bubble">${text}</div>
      </div>
    `;
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function addLoading() {
    const el = document.createElement("div");
    el.className = "msg bot";
    el.innerHTML = `<div class="bubble">⏳ Đang xử lý...</div>`;
    messagesEl.appendChild(el);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    return el;
  }

  /* ===== SEND MESSAGE ===== */
  async function sendMessage() {
    const text = inputEl.value.trim();
    if (!text) return;

    addUser(text);
    inputEl.value = "";

    const loading = addLoading();

    try {
      const res = await fetch(WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          page: location.pathname
        })
      });

      const data = await res.json();
      loading.remove();
      addBot(data.reply || "Xin lỗi, mình chưa hiểu câu hỏi.");

    } catch (err) {
      console.error(err);
      loading.remove();
      addBot("❌ Không thể kết nối chatbot.");
    }
  }

  /* ===== EVENTS ===== */
  inputEl.addEventListener("keydown", e => {
    if (e.key === "Enter") sendMessage();
  });

  document
    .querySelector(".chat-input button")
    .addEventListener("click", sendMessage);

});
