/* =========================================================
   SMART BUSINESS COMPARISON MODULE
   Version: FINAL – Fair, Explainable, Goal-based, Easy UI
   - No hard Min-Max => avoid 0 scores by "soft scoring"
   - Show raw values + score bars
   - Auto update on goal change
========================================================= */

/* ================= GLOBAL ================= */
let selectedCompare = [];
let dataset = [];
let chart = null;

/* ================= BUSINESS GOALS (WEIGHTS) ================= */
const GOALS = {
  cafe:    { price: 0.25, area: 0.20, rating: 0.35, demand: 0.20 },
  shop:    { price: 0.30, area: 0.30, rating: 0.20, demand: 0.20 },
  office:  { price: 0.35, area: 0.40, rating: 0.15, demand: 0.10 },
  home:    { price: 0.40, area: 0.30, rating: 0.20, demand: 0.10 },
  food:    { price: 0.35, area: 0.20, rating: 0.25, demand: 0.20 },
  factory: { price: 0.35, area: 0.55, rating: 0.05, demand: 0.05 }
};

/* ================= IDEAL AREA (BY GOAL) =================
   Dùng để chấm "phù hợp" thay vì "lớn nhất thắng"
========================================================= */
const IDEAL_AREA = {
  cafe: 100,
  shop: 70,
  office: 120,
  home: 80,
  food: 90,
  factory: 300
};

/* ================= RECEIVE DATA ================= */
document.addEventListener("data-ready", (e) => {
  dataset = (e.detail || []).map(x => ({
    ...x,
    gia: Number(x.gia || 0),
    dientich: Number(x.dientich || 0),
    avgRating: Number(x.avgRating || 0),
    reviewCount: Number(x.reviewCount || 0)
  }));

  console.log("📦 Dataset ready:", dataset.length);
});

/* =========================================================
   1) SOFT SCORING UTILITIES (0–10 but never 0 harshly)
========================================================= */
function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}
function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}

/**
 * Soft score based on how GOOD relative to center (median) and spread (IQR-ish).
 * reverse=true => smaller is better (price)
 * Output: 0.5..10 (avoid 0), then clamp to 0..10 for safety.
 */
function softScoreFromValues(value, values, reverse = false) {
  const arr = values.filter(v => Number.isFinite(v)).slice().sort((a,b)=>a-b);
  if (arr.length < 3) return 5;

  const median = arr[Math.floor(arr.length * 0.5)];
  const q1 = arr[Math.floor(arr.length * 0.25)];
  const q3 = arr[Math.floor(arr.length * 0.75)];
  const spread = Math.max(1e-9, (q3 - q1)); // avoid 0

  // z ~ how far from median (scaled by spread)
  let z = (value - median) / spread;
  if (reverse) z = -z;

  // map to (0..10) with sigmoid, keep floor at 0.5
  const s = 0.5 + 9.5 * sigmoid(2.2 * z); // 2.2 controls steepness
  return +clamp(s, 0, 10).toFixed(2);
}

/**
 * Area "fitness" scoring around an ideal value (goal-dependent)
 * close to ideal => high; far => lower, but not 0.
 */
function areaFitnessScore(area, goal) {
  const ideal = IDEAL_AREA[goal] || 80;
  const tol = ideal; // tolerance ~ ideal size (tunable)
  const s = 0.5 + 9.5 * Math.exp(-Math.abs(area - ideal) / tol);
  return +clamp(s, 0, 10).toFixed(2);
}

/**
 * Rating score with confidence (more reviews -> more trust)
 * Never 0 completely unless rating itself 0.
 */
function ratingConfidenceScore(avgRating, reviewCount) {
  const base = clamp(avgRating / 5, 0, 1); // 0..1
  const conf = 1 - Math.exp(-reviewCount / 6); // 0..~1
  const s = 0.5 + 9.5 * (base * (0.35 + 0.65 * conf));
  return +clamp(s, 0, 10).toFixed(2);
}

/**
 * Demand score uses log scaling; never 0 unless no dataset.
 */
function demandLogScore(reviewCount, maxReview) {
  const denom = Math.log((maxReview || 1) + 1);
  if (denom <= 0) return 5;
  const s01 = Math.log(reviewCount + 1) / denom; // 0..1
  const s = 0.5 + 9.5 * clamp(s01, 0, 1);
  return +clamp(s, 0, 10).toFixed(2);
}

/* =========================================================
   2) BUILD SCORE (FAIR + EXPLAINABLE)
   - Price: adjusted by area + quality ("đắt nhưng xứng đáng")
   - Area: fitness around ideal for goal
   - Rating: confidence-aware
   - Demand: log scaling
========================================================= */
function buildScore(item, goal) {
  const w = GOALS[goal] || GOALS.shop;

  // ---------- price "fairness": adjusted price per m2 / quality ----------
  const adjustedPrice =
    (item.gia / Math.max(1, item.dientich)) /
    (1 + 0.35 * item.avgRating + 0.18 * Math.log(item.reviewCount + 1));

  const adjustedPrices = dataset.map(x =>
    (x.gia / Math.max(1, x.dientich)) /
    (1 + 0.35 * (x.avgRating || 0) + 0.18 * Math.log((x.reviewCount || 0) + 1))
  );

  const priceScore = softScoreFromValues(adjustedPrice, adjustedPrices, true); // lower adjustedPrice => better

  // ---------- area fitness ----------
  const areaScore = areaFitnessScore(item.dientich, goal);

  // ---------- rating with confidence ----------
  const ratingScore = ratingConfidenceScore(item.avgRating, item.reviewCount);

  // ---------- demand ----------
  const maxReview = Math.max(...dataset.map(x => x.reviewCount || 0));
  const demandScore = demandLogScore(item.reviewCount, maxReview);

  const total =
    priceScore * w.price +
    areaScore * w.area +
    ratingScore * w.rating +
    demandScore * w.demand;

  return {
    price: priceScore,
    area: areaScore,
    rating: ratingScore,
    demand: demandScore,
    total: +total.toFixed(2),

    // raw values for table (easy to read)
    raw: {
      gia: item.gia,
      dientich: item.dientich,
      avgRating: item.avgRating,
      reviewCount: item.reviewCount,
      adjustedPrice: +adjustedPrice.toFixed(4)
    },
    weights: w
  };
}

/* =========================================================
   3) UI HELPERS (bars + formatting + explain)
========================================================= */
function fmtMoneyTrieu(v) {
  const n = Number(v || 0);
  return `${n.toLocaleString()} triệu/tháng`;
}
function fmtArea(v) {
  return `${Number(v || 0)} m²`;
}
function fmtRating(v) {
  return `${Number(v || 0).toFixed(1)} / 5`;
}
function fmtReviews(v) {
  return `${Number(v || 0)} đánh giá`;
}
function barHTML(score, colorClass = "a") {
  const pct = clamp((score / 10) * 100, 0, 100);
  return `
    <div class="cmp-bar ${colorClass}">
      <span style="width:${pct}%"></span>
    </div>
  `;
}
function goalLabel(goal) {
  return {
    cafe: "☕ Quán café",
    shop: "🛍 Shop bán lẻ",
    office: "🏢 Văn phòng",
    home: "🏠 Nhà ở",
    food: "🍜 Quán ăn",
    factory: "🏭 Xưởng / kho bãi"
  }[goal] || goal;
}

function explainAI(goal, A, B, sA, sB) {
  // weighted contributions difference
  const diffs = [
    { k: "price",  label: "Giá thuê hợp lý", d: (sA.price - sB.price) * sA.weights.price },
    { k: "area",   label: "Diện tích phù hợp", d: (sA.area - sB.area) * sA.weights.area },
    { k: "rating", label: "Đánh giá tin cậy", d: (sA.rating - sB.rating) * sA.weights.rating },
    { k: "demand", label: "Mức quan tâm", d: (sA.demand - sB.demand) * sA.weights.demand }
  ].sort((x,y)=>Math.abs(y.d)-Math.abs(x.d));

  const winA = sA.total >= sB.total;
  const winner = winA ? A : B;
  const loser  = winA ? B : A;

  const top = diffs.slice(0, 2).map(x => x.label).join(" & ");

  return `
    <div style="font-weight:800; margin-bottom:6px;">🤖 AI giải thích (mục tiêu: ${goalLabel(goal)})</div>
    <div style="opacity:.95; line-height:1.55;">
      <b>${winner.ten}</b> được đề xuất vì có lợi thế rõ hơn về <b>${top}</b> theo trọng số của mục tiêu này.
      Tổng điểm: <b>${A.ten}</b> = ${sA.total} | <b>${B.ten}</b> = ${sB.total}.
    </div>
    <div style="margin-top:8px; font-size:13px; opacity:.9; line-height:1.55;">
      • Giá được đánh giá theo <b>chi phí/m²</b> và được <b>điều chỉnh theo chất lượng (rating) & quan tâm</b> để tránh “đắt nhất = 0”.<br>
      • Diện tích được chấm theo mức <b>phù hợp với mục tiêu</b> (không phải càng lớn càng tốt).<br>
      • Đánh giá có xét <b>độ tin cậy</b> dựa trên số lượng đánh giá.
    </div>
  `;
}

/* =========================================================
   4) CHECKBOX EVENT (select max 2)
========================================================= */
document.addEventListener("change", (e) => {
  if (!e.target.classList.contains("compare-check")) return;

  const id = e.target.dataset.id;

  if (e.target.checked) {
    if (selectedCompare.length >= 2) {
      e.target.checked = false;
      alert("Chỉ được chọn 2 mặt bằng để so sánh");
      return;
    }
    selectedCompare.push(id);
  } else {
    selectedCompare = selectedCompare.filter(x => x !== id);
  }

  const bar = document.getElementById("compare-bar");
  if (bar) bar.style.display = selectedCompare.length ? "flex" : "none";
});

/* ================= AUTO UPDATE WHEN CHANGE GOAL ================= */
document.addEventListener("change", (e) => {
  if (e.target.id === "businessGoal" && selectedCompare.length === 2) {
    window.openCompare();
  }
});

/* =========================================================
   5) OPEN COMPARE (table + chart + explain)
========================================================= */
window.openCompare = function () {
  if (selectedCompare.length !== 2) {
    alert("Vui lòng chọn đúng 2 mặt bằng");
    return;
  }

  const goal = document.getElementById("businessGoal")?.value || "shop";

  const A = dataset.find(x => x.id == selectedCompare[0]);
  const B = dataset.find(x => x.id == selectedCompare[1]);
  if (!A || !B) return alert("Không tìm thấy dữ liệu mặt bằng");

  const sA = buildScore(A, goal);
  const sB = buildScore(B, goal);

  // ---------- TABLE (score + bar + raw values) ----------
  const tbody = document.getElementById("compare-table-body");
  if (!tbody) return alert("Thiếu #compare-table-body trong HTML");

  tbody.innerHTML = `
    <tr>
      <td><b>Giá thuê (hợp lý)</b><div class="cmp-note">Giá/m² có điều chỉnh chất lượng</div></td>
      <td>
        <div class="cmp-cell">
          <div class="cmp-score">${sA.price}</div>
          ${barHTML(sA.price, "a")}
          <div class="cmp-raw">${fmtMoneyTrieu(sA.raw.gia)} • ${fmtArea(sA.raw.dientich)}</div>
        </div>
      </td>
      <td>
        <div class="cmp-cell">
          <div class="cmp-score">${sB.price}</div>
          ${barHTML(sB.price, "b")}
          <div class="cmp-raw">${fmtMoneyTrieu(sB.raw.gia)} • ${fmtArea(sB.raw.dientich)}</div>
        </div>
      </td>
    </tr>

    <tr>
      <td><b>Diện tích (phù hợp)</b><div class="cmp-note">Chấm theo độ phù hợp mục tiêu</div></td>
      <td>
        <div class="cmp-cell">
          <div class="cmp-score">${sA.area}</div>
          ${barHTML(sA.area, "a")}
          <div class="cmp-raw">${fmtArea(sA.raw.dientich)}</div>
        </div>
      </td>
      <td>
        <div class="cmp-cell">
          <div class="cmp-score">${sB.area}</div>
          ${barHTML(sB.area, "b")}
          <div class="cmp-raw">${fmtArea(sB.raw.dientich)}</div>
        </div>
      </td>
    </tr>

    <tr>
      <td><b>Đánh giá (tin cậy)</b><div class="cmp-note">Có xét số lượng đánh giá</div></td>
      <td>
        <div class="cmp-cell">
          <div class="cmp-score">${sA.rating}</div>
          ${barHTML(sA.rating, "a")}
          <div class="cmp-raw">${fmtRating(sA.raw.avgRating)} • ${fmtReviews(sA.raw.reviewCount)}</div>
        </div>
      </td>
      <td>
        <div class="cmp-cell">
          <div class="cmp-score">${sB.rating}</div>
          ${barHTML(sB.rating, "b")}
          <div class="cmp-raw">${fmtRating(sB.raw.avgRating)} • ${fmtReviews(sB.raw.reviewCount)}</div>
        </div>
      </td>
    </tr>

    <tr>
      <td><b>Mức quan tâm</b><div class="cmp-note">Log scale (không tuyến tính)</div></td>
      <td>
        <div class="cmp-cell">
          <div class="cmp-score">${sA.demand}</div>
          ${barHTML(sA.demand, "a")}
          <div class="cmp-raw">${fmtReviews(sA.raw.reviewCount)}</div>
        </div>
      </td>
      <td>
        <div class="cmp-cell">
          <div class="cmp-score">${sB.demand}</div>
          ${barHTML(sB.demand, "b")}
          <div class="cmp-raw">${fmtReviews(sB.raw.reviewCount)}</div>
        </div>
      </td>
    </tr>

    <tr class="cmp-total">
      <td><b>TỔNG ĐIỂM</b><div class="cmp-note">Theo trọng số mục tiêu</div></td>
      <td><div class="cmp-total-score">${sA.total}</div></td>
      <td><div class="cmp-total-score">${sB.total}</div></td>
    </tr>
  `;

  // ---------- CHART (always 4 categories) ----------
  const ctx = document.getElementById("compareChart");
  if (!ctx) return alert("Thiếu canvas#compareChart trong HTML");

  if (chart) chart.destroy();
  chart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Giá", "Diện tích", "Đánh giá", "Quan tâm"],
      datasets: [
        { label: A.ten, data: [sA.price, sA.area, sA.rating, sA.demand], backgroundColor: "#3b82f6" },
        { label: B.ten, data: [sB.price, sB.area, sB.rating, sB.demand], backgroundColor: "#10b981" }
      ]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: "top" } },
      scales: {
        y: { min: 0, max: 10, title: { display: true, text: "Điểm (0–10)" } }
      }
    }
  });

  // ---------- WINNER ----------
  const win = document.getElementById("winner");
  if (win) win.innerText = sA.total >= sB.total ? A.ten : B.ten;

  // ---------- AI EXPLAIN ----------
  const explainBox = document.getElementById("aiExplain");
  if (explainBox) {
    explainBox.innerHTML = explainAI(goal, A, B, sA, sB);
  }

  // show modal
  const modal = document.getElementById("compare-modal");
  if (modal) modal.style.display = "flex";
};

/* ================= CLOSE MODAL ================= */
window.closeCompare = function () {
  const modal = document.getElementById("compare-modal");
  if (modal) modal.style.display = "none";
};
