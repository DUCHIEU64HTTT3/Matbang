/* ======================================
  TÍNH TRUNG BÌNH SAO TỪ REVIEWS (FIELD sao)
====================================== */
function calcAverageRating(reviews) {
  if (!reviews || typeof reviews !== "object") {
    return { avg: 0, count: 0 };
  }

  const list = Object.values(reviews);

  if (list.length === 0) {
    return { avg: 0, count: 0 };
  }

  const total = list.reduce((sum, r) => {
    return sum + Number(r.sao || 0);
  }, 0);

  return {
    avg: (total / list.length).toFixed(1),
    count: list.length
  };
}

/* ======================================
  RENDER DANH SÁCH MẶT BẰNG
====================================== */
export function render(data) {
  const container = document.getElementById("listings");
  container.innerHTML = "";

  data.forEach(item => {
    const isAdmin = window.currentUserRole === "admin";

    // ⭐ TÍNH ĐÁNH GIÁ TRUNG BÌNH
    const { avg, count } = calcAverageRating(item.reviews);

    container.innerHTML += `
      <div class="card ${item.phan_khuc}">
        
        <div class="card-image">
          <img 
            src="${item.hinhanh || 'images/no-image.png'}"
            alt="${item.ten}">
        </div>

        <div class="card-body">
          <h4>${item.ten}</h4>

          <p>📍 Địa chỉ: ${item.diachi || "Đang cập nhật"}</p>

          <!-- ✅ THÀNH PHỐ -->
          <p class="city">🏙 Thành phố: ${item.thanhpho || "Chưa cập nhật"}</p>

          <p>💰 Giá: ${Number(item.gia).toLocaleString()} triệu/tháng</p>
          <p>📐 Diện tích: ${item.dientich} m²</p>
          <p>🏠 Loại hình: ${item.loai}</p>
          <label class="compare-box">
            <input type="checkbox"
                   class="compare-check"
                   data-id="${item.id}">
            So sánh
          </label>

          
          <p class="rating">
            ⭐ ${avg} / 5
            <span style="color:#777">
              (${count} đánh giá)
            </span>
          </p>

          <p class="segment">${item.phan_khuc_text || ""}</p>

          <button class="detail-btn"
            onclick="location.href='detail.html?id=${item.id}'">
            Xem chi tiết
          </button>

          ${
            isAdmin
              ? `
                <button onclick="location.href='edit.html?id=${item.id}'">✏️ Sửa</button>
                <button onclick="location.href='delete.html?id=${item.id}'">🗑 Xóa</button>
              `
              : ""
          }
        </div>
      </div>
    `;
  });
  document.dispatchEvent(
    new CustomEvent("data-ready", {
      detail: data      
    })
  );
}
