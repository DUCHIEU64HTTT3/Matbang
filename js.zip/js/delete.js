import { db, auth } from "./firebase.js";
import {
  ref, remove, get, child
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const params = new URLSearchParams(window.location.search);
const id = params.get("id");

if (!id) {
  alert("Thiếu ID");
  location.href = "index.html";
}

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("Chưa đăng nhập");
    location.href = "login.html";
    return;
  }

  const roleSnap = await get(child(ref(db), `user/${user.uid}`));
  if (!roleSnap.exists() || roleSnap.val().role !== "admin") {
    alert("Không có quyền");
    location.href = "index.html";
  }
});

window.deletePost = async () => {
  await remove(ref(db, `matbang/${id}`));
  alert("🗑 Đã xóa bài");
  location.href = "index.html";
};
