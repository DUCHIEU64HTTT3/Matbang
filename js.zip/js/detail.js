import { auth, db } from "./firebase.js";
import { ref, get, push, onValue, update }
  from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

/* =========================
   🔎 LẤY ID BÀI
========================= */
const params = new URLSearchParams(window.location.search);
const id = params.get("id");

if (!id) {
  alert("Không tìm thấy bài đăng");
  location.href = "index.html";
}

const box = document.getElementById("detailBox");

/* =========================
   👤 USER HIỆN TẠI
========================= */
let currentUser = null;

/* =========================
   🔥 CHATRA PRO (UID = 1 USER)
========================= */
function initChatraPro(user) {
  if (!window.Chatra || !user) return;

  // 👉 Identify theo UID (CHÌA KHÓA)
  Chatra('identify', {
    external_id: user.uid,     // 🔑 QUAN TRỌNG NHẤT
    email: user.email,
    name: user.email,
    firebase_uid: user.uid
  });
}

/* =========================
   🔥 AUTH + CHATRA READY
========================= */
onAuthStateChanged(auth, user => {
  currentUser = user;

  if (!window.Chatra || !user) return;

  // Đợi Chatra sẵn sàng
  Chatra('on', 'ready', function () {
    initChatraPro(user);
  });
});

/* =========================
   📄 FIREBASE
========================= */
const postRef = ref(db, `matbang/${id}`);
const reviewsRef = ref(db, `matbang/${id}/reviews`);
let postData = null;

get(postRef).then(snap => {
  if (!snap.exists()) {
    alert("Bài đăng không tồn tại");
    location.href = "index.html";
    return;
  }

  postData = snap.val();
  renderDetail();
});

/* =========================
   🎨 RENDER
========================= */
function renderDetail() {
  box.innerHTML = `
    <div class="detail-top">
      <div class="detail-img">
        <img src="${postData.hinhanh}">
      </div>

      <div class="detail-info">
        <h2>${postData.ten}</h2>
        <p><b>Vị trí:</b> ${postData.diachi}</p>
        <p><b>Giá:</b> ${postData.gia.toLocaleString()} triệu/tháng</p>
        <p><b>Diện tích:</b> ${postData.dientich} m²</p>
        <p><b>Loại hình:</b> ${postData.loai}</p>
        <p class="avg-rating">
          ⭐ <span id="avgStar">0</span> / 5
        </p>
      </div>
    </div>

    <!-- MAP -->
    <div class="map-box">
      <h3>📍 Bản đồ vị trí</h3>
      <div id="map"></div>
    </div>

    <!-- REVIEW -->
    <div class="rating-box">
      <h3>Đánh giá khách hàng</h3>

      <div class="review-container">
        <div id="reviewList">Đang tải đánh giá...</div>
      </div>

      <h4>Gửi đánh giá của bạn</h4>
      <input id="reviewName" placeholder="Email"
        value="${currentUser?.email || ""}">
      <select id="reviewStar">
        <option value="1">⭐</option>
        <option value="2">⭐⭐</option>
        <option value="3">⭐⭐⭐</option>
        <option value="4">⭐⭐⭐⭐</option>
        <option value="5" selected>⭐⭐⭐⭐⭐</option>
      </select>
      <textarea id="reviewContent"
        placeholder="Viết đánh giá..."></textarea>
      <button id="btnReview">Gửi đánh giá</button>
    </div>
  `;

  document.getElementById("btnReview").onclick = submitReview;
  listenReviews();
  initMap();
}

/* =========================
   ⭐ REVIEW
========================= */
function listenReviews() {
  onValue(reviewsRef, snap => {
    const reviewList = document.getElementById("reviewList");
    const avgStarEl = document.getElementById("avgStar");

    if (!snap.exists()) {
      reviewList.innerHTML = "<p>Chưa có đánh giá nào.</p>";
      avgStarEl.innerText = "0";
      return;
    }

    let total = 0, count = 0, html = "";

    snap.forEach(child => {
      const r = child.val();
      total += Number(r.sao || 0);
      count++;

      html += `
        <div class="review-item">
          <b>${r.user}</b> – ${r.sao} ⭐
          <p>${r.noiDung}</p>
        </div>
        <hr>
      `;
    });

    const avg = Number((total / count).toFixed(1));
    avgStarEl.innerText = avg;

    reviewList.innerHTML = html;

    // ✅ CHỈ update khi khác
    if (postData?.danhgia !== avg) {
      update(postRef, { danhgia: avg });
      postData.danhgia = avg; // cập nhật local
    }
  });
}


async function submitReview() {
  if (!currentUser) {
    alert("Vui lòng đăng nhập để đánh giá");
    return;
  }

  const user = document.getElementById("reviewName").value.trim()
    || currentUser.email;
  const sao = Number(document.getElementById("reviewStar").value);
  const noiDung = document.getElementById("reviewContent").value.trim();

  if (!noiDung) return alert("Vui lòng nhập nội dung");

  await push(reviewsRef, {
    user,
    sao,
    noiDung,
    time: Date.now()
  });

  document.getElementById("reviewContent").value = "";
}

/* =========================
   🗺️ MAP
========================= */
async function geocodeAddress(address) {
  const url =
    "https://nominatim.openstreetmap.org/search?format=json&q=" +
    encodeURIComponent(address);

  const res = await fetch(url);
  const data = await res.json();

  if (!data || data.length === 0) return null;

  return {
    lat: data[0].lat,
    lng: data[0].lon
  };
}

async function initMap() {
  const mapEl = document.getElementById("map");
  if (!mapEl || !postData?.diachi) return;

  const location = await geocodeAddress(postData.diachi);
  if (!location) {
    mapEl.innerHTML = "<p>Không tìm thấy vị trí</p>";
    return;
  }

  const map = L.map("map").setView(
    [location.lat, location.lng],
    15
  );

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© OpenStreetMap"
  }).addTo(map);

  L.marker([location.lat, location.lng])
    .addTo(map)
    .bindPopup(`<b>${postData.ten}</b><br>${postData.diachi}`)
    .openPopup();
}
