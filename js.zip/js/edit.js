import { db, auth } from "./firebase.js";
import {
  ref, get, update, child
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { onAuthStateChanged } from
  "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// 👉 LẤY ID BÀI
const params = new URLSearchParams(window.location.search);
const id = params.get("id");

if (!id) {
  alert("Thiếu ID bài đăng");
  location.href = "index.html";
}

// 🔐 CHECK ADMIN
onAuthStateChanged(auth, async (user) => {
  if (!user) {
    alert("Chưa đăng nhập");
    location.href = "login.html";
    return;
  }

  const roleSnap = await get(child(ref(db), `user/${user.uid}`));
  if (!roleSnap.exists() || roleSnap.val().role !== "admin") {
    alert("Không có quyền");
    location.href = "index.html";
    return;
  }

  loadData();
});

// 📥 LOAD DATA
async function loadData() {
  const snap = await get(ref(db, `matbang/${id}`));
  if (!snap.exists()) return;

  const d = snap.val();

  ten.value = d.ten || "";
  diachi.value = d.diachi || "";
  thanhpho.value = d.thanhpho || ""; // ✅ THÀNH PHỐ
  gia.value = d.gia || "";
  dientich.value = d.dientich || "";
  loai.value = d.loai || "Shop";
  phan_khuc.value = d.phan_khuc || "tiemnang";
  hinhanh.value = d.hinhanh || "";
}

// 💾 UPDATE
window.updatePost = async () => {
  await update(ref(db, `matbang/${id}`), {
    ten: ten.value.trim(),
    diachi: diachi.value.trim(),
    thanhpho: thanhpho.value.trim(), // ✅ THÀNH PHỐ
    gia: Number(gia.value),
    dientich: Number(dientich.value),
    loai: loai.value,
    phan_khuc: phan_khuc.value,
    phan_khuc_text:
      phan_khuc.value === "caocap"
        ? "Cao cấp (TB: 20tr - 50m²)"
        : "Tiềm năng (TB: 10tr - 30m²)",
    hinhanh: hinhanh.value.trim()
  });

  alert("✅ Đã cập nhật");
  location.href = "index.html";
};
