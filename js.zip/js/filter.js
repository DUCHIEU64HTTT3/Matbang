function applyFilter() {
  const min = document.getElementById("minPrice").value || 0;
  const max = document.getElementById("maxPrice").value || Infinity;
  const type = document.getElementById("type").value;

  const filtered = data.filter(item =>
    item.gia >= min && item.gia <= max && item.loai === type
  );

  const container = document.getElementById("listings");
  container.innerHTML = "";
  filtered.forEach(item => {
    container.innerHTML += `
      <div class="card">
        <img src="${item.hinhanh}">
        <h4>${item.ten}</h4>
        <p>Giá: ${item.gia/1e6} triệu</p>
      </div>`;
  });
}