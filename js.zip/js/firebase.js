// js/firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyD49sciWFFFfHTwHkrp3eSV_ZA6HJKvaik",
  authDomain: "thicuoiky1-ce4da.firebaseapp.com",
  databaseURL: "https://thicuoiky1-ce4da-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "thicuoiky1-ce4da",
  storageBucket: "thicuoiky1-ce4da.appspot.com",
  messagingSenderId: "68485398147",
  appId: "1:68485398147:web:1adc21b067fcb2cbc965b6"
};

// 🔥 INIT DUY NHẤT 1 LẦN
export const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
export const auth = getAuth(app);
