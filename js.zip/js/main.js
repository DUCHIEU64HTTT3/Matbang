import { db } from "./firebase.js";
import { ref, onValue } from
  "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { render } from "./data.js";

let cachedData = [];

// 🔁 LẮNG NGHE DỮ LIỆU
onValue(ref(db, "matbang"), (snapshot) => {
  const obj = snapshot.val();
  if (!obj) return;

  cachedData = Object.entries(obj).map(([id, value]) => ({
    id,
    ...value
  }));

  render(cachedData);
});

// 🔔 KHI ROLE ĐÃ SẴN SÀNG → RENDER LẠI
window.addEventListener("role-ready", () => {
  if (cachedData.length > 0) {
    render(cachedData);
  }
});
/* ===============================
   FILTER ⭐ HOT – TOP 5 SAO CAO NHẤT
================================ */
function filterHot() {
  const cloned = [...cachedData];

  cloned.forEach(item => {
    const reviews = item.reviews || {};
    const list = Object.values(reviews);

    let avg = 0;
    if (list.length > 0) {
      const total = list.reduce(
        (sum, r) => sum + Number(r.sao || 0), 0
      );
      avg = total / list.length;
    }

    item._avgRating = avg;
  });

  cloned.sort((a, b) => b._avgRating - a._avgRating);

  render(cloned.slice(0, 5));
}

/* ===============================
   CLICK ⭐ HOT
================================ */
document.getElementById("filterHot")
  ?.addEventListener("click", () => {
    filterHot();
  });

/* ===============================
   ROLE READY → RENDER LẠI
================================ */
window.addEventListener("role-ready", () => {
  if (cachedData.length > 0) {
    render(cachedData);
  }
});
/* ===============================
   CLICK 🔥 MỚI NHẤT – LOAD LẠI ALL
================================ */
document.getElementById("filterNewest")
  ?.addEventListener("click", () => {
    if (cachedData.length > 0) {
      render(cachedData);
    }
  });