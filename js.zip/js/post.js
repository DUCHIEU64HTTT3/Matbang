import { auth, db } from "./firebase.js";
import { ref, get, push, update, remove } from
  "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";
import { onAuthStateChanged } from
  "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";

// LẤY ID KHI EDIT
const params = new URLSearchParams(location.search);
const editId = params.get("id");

// 🔐 CHẶN USER THƯỜNG
onAuthStateChanged(auth, async (user) => {
  if (!user) location.href = "login.html";

  const snap = await get(ref(db, `user/${user.uid}`));
  if (!snap.exists() || snap.val().role !== "admin") {
    alert("Không có quyền");
    location.href = "index.html";
  }

  // ✏️ LOAD DỮ LIỆU KHI SỬA
  if (editId) {
    const postSnap = await get(ref(db, `matbang/${editId}`));
    const d = postSnap.val();

    ten.value = d.ten || "";
    diachi.value = d.diachi || "";
    thanhpho.value = d.thanhpho || ""; // ✅ THÀNH PHỐ
    gia.value = d.gia || "";
    dientich.value = d.dientich || "";
    loai.value = d.loai || "";
    phan_khuc.value = d.phan_khuc || "";
    hinhanh.value = d.hinhanh || "";
  }
});

// 💾 LƯU (THÊM / SỬA)
window.addPost = () => {
  const data = {
    ten: ten.value.trim(),
    diachi: diachi.value.trim(),
    thanhpho: thanhpho.value.trim(), // ✅ THÀNH PHỐ
    gia: Number(gia.value),
    dientich: Number(dientich.value),
    loai: loai.value,
    phan_khuc: phan_khuc.value,
    hinhanh: hinhanh.value.trim(),
    danhgia: 5
  };

  const action = editId
    ? update(ref(db, `matbang/${editId}`), data)
    : push(ref(db, "matbang"), data);

  action.then(() => {
    alert("Lưu thành công");
    location.href = "index.html";
  });
};

// ❌ XÓA
window.deletePost = (id) => {
  if (!confirm("Xóa bài?")) return;
  remove(ref(db, `matbang/${id}`));
};

// ✏️ CHUYỂN SANG TRANG SỬA
window.editPost = (id) => {
  location.href = `post.html?id=${id}`;
};
