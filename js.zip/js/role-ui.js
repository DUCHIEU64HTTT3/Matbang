import { auth, db } from "./firebase.js";
import { onAuthStateChanged }
  from "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js";
import { ref, get }
  from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

onAuthStateChanged(auth, async (user) => {
  const userBtn = document.getElementById("chatUserBtn");
  const adminBtn = document.getElementById("chatAdminBtn");

  // Mặc định ẩn cả 2
  if (userBtn) userBtn.style.display = "none";
  if (adminBtn) adminBtn.style.display = "none";

  // Chưa login → cho user chat
  if (!user) {
    if (userBtn) userBtn.style.display = "block";
    return;
  }

  // Lấy role
  const roleSnap = await get(ref(db, `user/${user.uid}/role`));

  if (roleSnap.exists() && roleSnap.val() === "admin") {
    // 🧑‍💼 ADMIN
    if (adminBtn) adminBtn.style.display = "block";
  } else {
    // 👤 USER
    if (userBtn) userBtn.style.display = "block";
  }
});
