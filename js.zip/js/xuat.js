// js/xuat.js
import { db } from "./firebase.js";
import { ref, get } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js";

async function exportFirebaseData() {
  const snapshot = await get(ref(db, "/"));

  if (!snapshot.exists()) {
    alert("❌ Không có dữ liệu trong Firebase");
    return;
  }

  const data = snapshot.val();

  const blob = new Blob(
    [JSON.stringify(data, null, 2)],
    { type: "application/json" }
  );

  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "firebase_export.json";
  a.click();

  URL.revokeObjectURL(a.href);
}

exportFirebaseData();
